<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link https://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class LocationsController extends AppController {

/**
 * This controller does not use a model
 *
 * @var array
 */
	public $uses = array();

        function index() {
            echo "<pre>";
            print_r($this->Location->find('all'));
            echo "</pre>";            
            exit;
        }
        function userLocation(){
            //$this->printInFile(__FUNCTION__,$_REQUEST,TRUE);
            $response['flag'] = 1;
            $response['status'] = 1;
            $locationData['latitude']=$_POST['latitude'];
            $locationData['longitude']=$_POST['longitude'];
            $this->Location->save($locationData);
            //$this->printInFile(__FUNCTION__,$this->Location->id,TRUE);
            echo json_encode($response);        
            exit;
        }
        function printInFile($fileName,$printArray,$isAppend) {
        if($isAppend)
            file_put_contents($fileName.".txt",print_r($printArray,true),FILE_APPEND);
        else
            file_put_contents($fileName.".txt", print_r($printArray,true));
    }
        
}
