package com.google.android.gms.location.sample.locationupdatesforegroundservice.retrofit;




import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Streaming;

/**
 * Created by Shyam on 9/29/2017.
 */

public interface RetrofitService {

   public static final String BASE_URL = "http://192.168.1.105/UserLocation/Locations/";


    Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build();

    @FormUrlEncoded
    @POST("userLocation")
    Call<ServerResponse> sendLocation(@Field("latitude") double latitude, @Field("longitude") double longitude);

}
