package com.google.android.gms.location.sample.locationupdatesforegroundservice.retrofit;

/**
 * Created by Shyam on 10/13/2017.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ServerResponse {

    @SerializedName("flag")
    @Expose
    private Integer flag;
    @SerializedName("status")
    @Expose
    private Integer status;

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ServerResponse{" +
                "flag=" + flag +
                ", status=" + status +
                '}';
    }
}